<?php
include('dbconfig.php');

$_SESSION['week_no'] = 1 ;

echo "<script>
window.location.href='assesment1.php';
</script>";

?>
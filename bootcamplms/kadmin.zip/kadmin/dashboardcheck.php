<?php
echo "<script>

window.location.href='dashboard';
</script>";
?>
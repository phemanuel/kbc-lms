<?php
include('dbconfig.php');

$_SESSION['week_no'] = 2 ;
$_SESSION['outline'] = "virtual Assistance";

echo "<script>
window.location.href='project1';
</script>";

?>
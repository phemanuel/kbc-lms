<?php
include('dbconfig.php');

$_SESSION['week_no'] = 1 ;
$_SESSION['outline'] = "Social Media Management";

echo "<script>
window.location.href='project1';
</script>";

?>
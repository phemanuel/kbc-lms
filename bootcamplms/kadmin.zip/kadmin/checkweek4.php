<?php
include('dbconfig.php');

$_SESSION['week_no'] = 4 ;
$_SESSION['outline'] = "Customer Support";

echo "<script>
window.location.href='project1';
</script>";

?>
<?php
include('dbconfig.php');

$_SESSION['week_no'] = 3 ;
$_SESSION['outline'] = "Lead Generation";

echo "<script>
window.location.href='project1';
</script>";

?>